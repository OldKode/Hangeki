# -*- coding: cp1252 -*-
import pygame

def lerArquivo():
    #abre o arquivo
    arquivo = open('resources\\parametros.leo', 'r')
    #le o arquivo
    linha = arquivo.read()
    #quebra as linhas da lista em uma lista de string
    listaStr = linha.splitlines()
    #percorre todas as posicoes da lista de strings
    for inf in listaStr:
        #quebra as ocorencias (linha) em parametros para serem tratatos
        informacao = inf.split()
        #caso a primeira posicao (come�o da linha) for = janela, ja sei que os proximos parametros sao largura e altura
        if(informacao[0] == 'janela' ):
            #caso o tamanho seja menor do que 2, quer dizer que faltam informacoes na linha
            if(len(informacao) < 2):
                break
            #caso estiver tudo certo atribui os valores as variaveis
            global larg_disp,alt_disp
            larg_disp = int(informacao[1])
            alt_disp = int(informacao[2])

        #caso a primeira posicao (come�o da linha) for = ponto_inicial, ja sei que o proximo parametro � a posicao
        if(informacao[0] == 'controle'):
            if(len(informacao) < 1):
                break
            global controle
            controle = int(informacao[1])
    #fecha arquivo
    arquivo.close()
    
def gravaArquivo(nome_arquivo, texto, acao):
    '''
    acao = 1 - Gravar adicionando o texto (mantendo o texto anterior)
    acao = 2 - Gravar somente o texto passad (limpando o arquivo e gravando somente o texto)
    '''
    if(acao == 2):
        file = open(nome_arquivo, "w")
        file.write(texto)
    if(acao == 1):
        file = open(nome_arquivo, "a")
        file.write('\n'+texto)
    file.close()

def lerScore():
    #abre o arquivo
    arquivo = open('resources\\pontuacoes.leo', 'r')
    #le o arquivo
    linha = arquivo.read()
    #quebra as linhas da lista em uma lista de string
    listaStr = linha.splitlines()
    #percorre todas as posicoes da lista de strings
    listaStr = bubble_sort(listaStr)
    #fecha arquivo
    arquivo.close()
    return listaStr

def bubble_sort(lista):
    for i in range(0, len(lista)-1):
        for j in range(0, len(lista)-1-i):
            if lista[ j ] < lista[j + 1]:
                lista[j], lista[j + 1] = lista[j + 1], lista[j]
    return lista